# TAI.1
Códigos gerados e ministrados em aula; Tópicos Avançados em Informática I 2018.2

-Regressão Linear

Código1 - Código modificado através dos primeiros passos de regressão linear dado em sala.
OBS* Conseguimos utilizar os dados fornecidos e plotar o gráfico, porém não foi utilizada a opção de random, deixando os dados em ordem e deixando a plotagem de uma forma mais simples.

Código2 - Gerado através do 'Code1', utilizado na primeira aula, ao qual foi descoberto o lucro dado pela startup, através dos dados fornecidos.
OBS* A parte comentada foi dada em sala. A parte ao final do código foi feito em sala através do entendimento do arquivo ministrado.

-Percepetron


Código1 - Ajustando os dados de uma clusterização, percebendo seus padrões e agrupando novos dados com a manipulação dos vetores.

-SVM


Código1 - SVM com kernel linear para classificar se uma pessoa poderia adquirir um SUV baseado em sua idade e salário.

Código2 - Utilizando os parâmetros de gamma e custo que melhor se adequam a melhor taxa de acerto da SVM com Kernel em RBF.


